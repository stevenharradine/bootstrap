#!/usr/bin/env python2

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


CLIENT_VERSION = '63'
_AUTHOR = 'mullvad'
_APP_NAME = 'mullvad'
